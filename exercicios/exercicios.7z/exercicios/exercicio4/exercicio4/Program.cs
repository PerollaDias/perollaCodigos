﻿Aluno Perolla = new Aluno();
Perolla.nome = "Pérolla";
Perolla.email = "perolla@gmail.com";
Perolla.nota1 = 10;
Perolla.nota2 = 8;
Perolla.CalcularMedia();

Console.WriteLine($"{Perolla.nome} \n{Perolla.email} \n");

Aluno Gaby = new Aluno();
Gaby.nome = "Gaby";
Gaby.email = "gaby@gmail.com";
Gaby.nota1 = 6;
Gaby.nota2 = 10;
Gaby.CalcularMedia();

Console.WriteLine($"{Gaby.nome} \n{Gaby.email} \n");

Aluno Rhi = new Aluno();
Rhi.nome = "Rhi";
Rhi.email = "Rhi@gmail.com";
Rhi.nota1 = 5;
Rhi.nota2 = 2;
Rhi.CalcularMedia();

Console.WriteLine($"{Rhi.nome} \n{Rhi.email}");