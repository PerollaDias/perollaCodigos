﻿public class Conta
{ 
    public double Soma(double soma1, double soma2)
    {
        double soma = soma1 + soma2;
        return soma;
    }

    public double Subtrair(double subtrair1,double subtrair2)
    {
        double subtrair = (subtrair1 - subtrair2);
        return subtrair;
    }
    public double Multiplicar(double multiplicar1,double multiplicar2)
    {
        double multiplicar = (multiplicar1 * multiplicar2);
        return multiplicar;
            }

    public double Divisão(double dividir1,double dividir2)
    {
        double divisao = (dividir1 / dividir2);
        return divisao;
        
    }


    
}