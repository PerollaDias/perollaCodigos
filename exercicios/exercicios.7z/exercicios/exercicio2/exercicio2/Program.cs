﻿Conta conta = new Conta();

double resultadosoma = conta.Soma(10, 20);
Console.WriteLine($"O resultado da soma é: {resultadosoma}\n");

double resultadosubtracao = conta.Subtrair(10, 20);
Console.WriteLine($"O resultado da subtração é: {resultadosubtracao}\n");

double resultadomultiplicacao = conta.Multiplicar(10, 20);
Console.WriteLine($"O resultado da multiplicação é: {resultadomultiplicacao} \n");

double resultadodivisao = conta.Divisão(10, 20);
Console.WriteLine($"O resultado da divisão é: {resultadodivisao}");


